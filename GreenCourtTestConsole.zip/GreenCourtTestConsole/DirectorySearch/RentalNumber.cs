﻿namespace NumberRental
{
    public class RentalNumber
    {
        public bool Rented { get; set; }
        public int NumberName { get; set; }
    }
}